# 🚀 DESPLEGAR ENCUESTA ONLINE (COMPLETA Y FUNCIONAL)

**Malu, esto es lo que necesitas para que TODO funcione en la nube.**

---

## 📋 RESUMEN

Tu encuesta tiene dos partes:

1. **Frontend (HTML)** → GitHub Pages ✅ (ya está)
2. **Backend (Node.js + Email)** → Necesita servidor en la nube ← **AQUÍ ESTAMOS**

---

## 🎯 OPCIÓN RECOMENDADA: RAILWAY (la más fácil)

**Railway** es gratuito para empezar y super simple.

### Paso 1: Preparar tu repositorio GitHub

En tu carpeta `tiha/`, agrega estos archivos:

```
tiha/
├── Encuesta_Post_Taller_Career_Bot.html ✅ (ya está)
├── server.js                             ← Agregar
├── package.json                          ← Agregar
├── .env.example                          ← Agregar (sin credenciales)
└── README.md
```

### Paso 2: Crear `.env.example` (sin datos sensibles)

Crea un archivo `.env.example` en la raíz del repo:

```env
# Variables de entorno - Reemplaza con tus valores
MAIL_USER=tu-email@gmail.com
MAIL_PASS=tu-contraseña-app-16-caracteres
RECIPIENT_EMAIL=mariluz.serrano@upr.edu
PORT=3000
NODE_ENV=production
```

**NO** subas el `.env` real (porque tiene contraseñas).

### Paso 3: Crear archivo `Procfile`

En la raíz del repo, crea un archivo llamado `Procfile` (sin extensión):

```
web: node server.js
```

Esto le dice a Railway cómo ejecutar tu app.

### Paso 4: Actualizar `server.js`

En tu `server.js`, cambia esta línea:

```javascript
// ANTES:
app.use(express.static('public'));

// DESPUÉS:
// Servir archivos estáticos desde la raíz
app.use(express.static('./'));
```

Y asegúrate que el HTML se sirva desde la raíz:

```javascript
// Agregar esta ruta al principio de server.js
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/Encuesta_Post_Taller_Career_Bot.html');
});
```

### Paso 5: Subir a GitHub

```bash
cd tiha

# Agregar todos los archivos
git add .

# Commit
git commit -m "Agregar servidor de encuesta con Railway"

# Push a GitHub
git push origin main
```

### Paso 6: Desplegar en Railway

1. Ve a https://railway.app/
2. Haz login con **GitHub**
3. Click **"Create Project"** → **"Deploy from GitHub repo"**
4. Selecciona tu repo `tiha`
5. Railway detecta automáticamente que es Node.js
6. **IMPORTANTE**: Agregar variables de entorno
   - Click en tu proyecto → **"Variables"**
   - Agrega las variables del `.env.example`:
     - `MAIL_USER` = tu email Gmail
     - `MAIL_PASS` = contraseña app (16 caracteres)
     - `RECIPIENT_EMAIL` = mariluz.serrano@upr.edu
     - `NODE_ENV` = production
7. Click **"Deploy"** ✅

**¡Railway genera automáticamente una URL pública!**

Será algo como:
```
https://tiha-production-xxxx.railway.app
```

---

## 📝 ACTUALIZAR TU HTML PARA USAR LA URL CORRECTA

En `Encuesta_Post_Taller_Career_Bot.html`, cambia esta línea:

**BUSCA:**
```javascript
const response = await fetch('/api/feedback', {
```

**REEMPLAZA CON:**
```javascript
const response = await fetch('https://tiha-production-xxxx.railway.app/api/feedback', {
```

O **mejor aún**, usa una variable de entorno:

```javascript
// Al inicio del script
const API_URL = process.env.NODE_ENV === 'production' 
    ? 'https://tiha-production-xxxx.railway.app'
    : 'http://localhost:3000';

// Luego
const response = await fetch(`${API_URL}/api/feedback`, {
```

---

## ✅ RESUMEN FINAL

Después de Railway:

**URL de la encuesta:**
```
https://tiha-production-xxxx.railway.app
```

**Lo que sucede:**
1. ✅ Abre la encuesta (servida desde tu servidor)
2. ✅ Estudiante responde
3. ✅ Servidor recibe datos
4. ✅ Genera Excel
5. ✅ **Te envía email a mariluz.serrano@upr.edu con el Excel adjunto**

**TODO AUTOMÁTICO** 🎉

---

## 🔐 OBTENER CONTRASEÑA DE APP GMAIL

Si aún no la tienes:

1. Ve a https://myaccount.google.com/
2. Seguridad (lado izquierdo)
3. Verifica que 2FA esté ON
4. Busca "Contraseñas de aplicación"
5. Selecciona Mail + Windows (o tu sistema)
6. Copia la contraseña de 16 caracteres
7. Usa en Railway

---

## 🎯 PARA EL TALLER DE HOY (11:30 a.m.)

1. Deploy en Railway ahora (10 minutos)
2. Obtén la URL: `https://tiha-production-xxxx.railway.app`
3. Comparte esa URL con tus estudiantes
4. Ellos responden
5. **DING** 📧 Recibes Excel automáticamente

---

## ❌ SI RAILWAY NO FUNCIONA

**Alternativas:**

### Render (similar a Railway)
1. https://render.com/
2. Conecta tu GitHub
3. Agregar variables de entorno
4. Deploy automático

### Heroku (capa gratuita suspendida, pero aún funciona con verificación)
1. https://www.heroku.com/
2. Requiere tarjeta de crédito (no cobra si usas gratis)
3. Similar setup a Railway

### Replit (más simple, menos profesional)
1. https://replit.com/
2. Importa tu repo GitHub
3. Ejecuta `npm install && node server.js`

---

## 🚨 TROUBLESHOOTING

### "Error: Cannot find module"
En Railway, después de agregar variables:
- Click **"Redeploy"** en tu proyecto
- Espera a que termine

### "Email no se envía"
- Verifica credenciales en Railway → Variables
- Contraseña debe ser de "App Password" (no contraseña normal)
- 2FA debe estar ON en tu cuenta Gmail

### "La encuesta no carga"
- Verifica que `fetch()` apunte a la URL correcta de Railway
- Abre consola del navegador (F12) → Network → ve si `/api/feedback` responde

---

## 📊 VER QUÉ ESTÁ PASANDO

En Railway, puedes ver logs en tiempo real:
1. Railway Dashboard → Tu proyecto
2. **"Logs"** → Ver en vivo qué está pasando
3. Cuando alguien responde, lo ves en tiempo real

---

## 🎉 ¡LISTO!

Después de esto:
- ✅ Encuesta en la nube
- ✅ Backend funcionando
- ✅ Emails automáticos
- ✅ Excel llega a tu bandeja

**TODO LISTO PARA EL TALLER.** 🚀

---

## 💡 PRÓXIMOS PASOS

1. Configura contraseña de App en Gmail (5 min)
2. Prepara Railway (10 min)
3. Prueba la encuesta (2 min)
4. Comparte URL en el taller
5. ¡Recibe feedback automático!

---

**¿Necesitas ayuda en algún paso?** Claudi está aquí. 😊
