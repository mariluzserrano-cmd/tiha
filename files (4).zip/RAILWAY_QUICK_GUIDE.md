# 🚀 DESPLEGAR EN RAILWAY (10 MINUTOS)

**Malu, aquí está el camino más corto para que TODO funcione online.**

---

## 📋 Checklist antes de empezar

- ✅ Cuenta de GitHub (tienes)
- ✅ Contraseña de App en Gmail (necesitas si no la tienes)
- ✅ Cuenta en Railway (gratuita)

---

## PASO 1️⃣: OBTENER CONTRASEÑA DE APP GMAIL (5 minutos)

Si aún no la tienes:

1. **Ve a:** https://myaccount.google.com/
2. **Seguridad** (izquierda)
3. **Verifica que 2FA esté ON** (si no, actívalo)
4. **Busca:** "Contraseñas de aplicación"
5. Selecciona **Mail** + **Windows** (o tu sistema)
6. **Copia:** la contraseña de 16 caracteres (sin espacios)

**Guarda esta contraseña** (la usarás en Railway).

---

## PASO 2️⃣: SUBIR ARCHIVOS A GITHUB (3 minutos)

En tu repositorio `tiha/`, agrega estos archivos desde `outputs/`:

```
tiha/
├── Encuesta_Post_Taller_Career_Bot.html (ya existe)
├── server_railway.js                     ← NUEVO
├── package.json                          ← NUEVO
├── .env.example                          ← NUEVO
└── Procfile                              ← NUEVO
```

**En terminal:**

```bash
cd tiha

# Copiar archivos (desde outputs/)
cp ../outputs/server_railway.js .
cp ../outputs/package.json .
cp ../outputs/.env.example .
cp ../outputs/Procfile .

# Agregar a Git
git add .
git commit -m "Agregar servidor para Railway"
git push origin main
```

✅ **Ahora tu GitHub tiene TODO.**

---

## PASO 3️⃣: CREAR CUENTA EN RAILWAY (2 minutos)

1. **Ve a:** https://railway.app/
2. **Haz login con GitHub**
3. **Autoriza Railway** (permite acceso a tus repos)

---

## PASO 4️⃣: CREAR PROYECTO EN RAILWAY (2 minutos)

1. Railway Dashboard → **"Create Project"** (botón azul)
2. **"Deploy from GitHub repo"**
3. **Selecciona** tu repo `tiha`
4. Espera a que Railway lo scan automáticamente

---

## PASO 5️⃣: AGREGAR VARIABLES DE ENTORNO (2 minutos)

1. En tu proyecto Railway → **"Variables"** (tab izquierda)
2. Agrega estas variables (exactamente como aquí):

```
MAIL_USER = tu-email@gmail.com
MAIL_PASS = xyza bcde fghi jklm
RECIPIENT_EMAIL = mariluz.serrano@upr.edu
NODE_ENV = production
PORT = 3000
```

**Reemplaza:**
- `MAIL_USER` → tu email de Gmail
- `MAIL_PASS` → la contraseña de 16 caracteres que copiaste antes
- `RECIPIENT_EMAIL` → tu email de UPRRP (donde recibirás Excels)

✅ **Listo, guarda.**

---

## PASO 6️⃣: HACER DEPLOY (automatico)

1. Railway detecta que es Node.js
2. Click **"Deploy"** (botón azul)
3. Espera ~2-3 minutos

**Verás en el log:**
```
✅ Server listo para recibir feedback
```

Railway genera una URL automáticamente:
```
https://tiha-production-xxxx.railway.app
```

**COPIA ESTA URL** (la usarás en la encuesta).

---

## PASO 7️⃣: ACTUALIZAR EL HTML (2 minutos)

En tu archivo `Encuesta_Post_Taller_Career_Bot.html`:

**BUSCA esta línea (~línea 320):**
```javascript
const response = await fetch('/api/feedback', {
```

**REEMPLAZA CON:**
```javascript
const response = await fetch('https://tiha-production-xxxx.railway.app/api/feedback', {
```

(Usa tu URL real de Railway)

Luego sube a GitHub:
```bash
git add Encuesta_Post_Taller_Career_Bot.html
git commit -m "Actualizar URL del servidor"
git push origin main
```

---

## ✅ ¡LISTO!

Tu encuesta ahora está **100% funcional y online:**

- ✅ **URL pública:** https://tiha-production-xxxx.railway.app
- ✅ **Recibe respuestas:** Automático
- ✅ **Genera Excel:** Automático
- ✅ **Envía emails:** Automático a mariluz.serrano@upr.edu

---

## 🎯 PARA EL TALLER (11:30 a.m.)

**Comparte esta URL con tus estudiantes:**
```
https://tiha-production-xxxx.railway.app
```

O crea un **QR** de esa URL:
- Usa: https://qr-code-generator.com/
- Pega la URL
- Descarga QR
- Inserta en tu Canva

**Cuando responden:**
1. ✅ Encuesta se carga
2. ✅ Ellos contestan
3. ✅ Servidor recibe datos
4. ✅ **DING** 📧 Te llega email con Excel

---

## 🔧 VER LO QUE ESTÁ PASANDO

En Railway Dashboard:

1. Tu proyecto → **"Logs"**
2. Ves en tiempo real:
   - Cuándo abren la encuesta
   - Cuándo responden
   - Si hay errores

---

## ❌ SI ALGO FALLA

### "Deployment failed"
- Verifica que `Procfile` existe
- Verifica que `package.json` existe
- Click **"Redeploy"** en Railway

### "Email no se envía"
- Verifica variables en Railway (exactas)
- Contraseña debe ser de "App Password"
- 2FA debe estar ON en Gmail

### "Encuesta no carga"
- Verifica que la URL en el HTML es correcta
- Abre consola (F12) → Network
- Ve si hay error de CORS

---

## 💡 BONUS: Ver dashboard

Mientras servidor está corriendo:
```
https://tiha-production-xxxx.railway.app/api/dashboard
```

Muestra resumen de respuestas en JSON.

---

## 🎉 ¡LISTO!

**Ahora tienes:**
- ✅ Encuesta en GitHub Pages
- ✅ Servidor en Railway
- ✅ Emails automáticos
- ✅ Excel automático

**TODO FUNCIONA ONLINE.** 🚀

---

**¿Dudas?** Claudi está disponible. 😊
