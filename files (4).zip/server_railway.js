/**
 * SERVIDOR ENCUESTA POST-TALLER CAREER BOT
 * ✅ COMPATIBLE CON RAILWAY, HEROKU, RENDER, ETC.
 * 
 * Recibe respuestas → Genera Excel → Envía por email automáticamente
 */

const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
const XLSX = require('xlsx');
const bodyParser = require('body-parser');
require('dotenv').config();
const path = require('path');
const fs = require('fs');

const app = express();

// =====================================================
// MIDDLEWARE
// =====================================================
app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));

// Servir archivos estáticos desde la raíz
app.use(express.static('./'));

// =====================================================
// CONFIGURACIÓN
// =====================================================
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const MAIL_USER = process.env.MAIL_USER;
const MAIL_PASS = process.env.MAIL_PASS;
const RECIPIENT_EMAIL = process.env.RECIPIENT_EMAIL || 'mariluz.serrano@upr.edu';

// Validar variables de entorno en producción
if (NODE_ENV === 'production') {
    if (!MAIL_USER || !MAIL_PASS) {
        console.error('❌ ERROR: MAIL_USER y MAIL_PASS son requeridos en producción');
        process.exit(1);
    }
}

// =====================================================
// NODEMAILER CONFIGURATION
// =====================================================
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: MAIL_USER,
        pass: MAIL_PASS
    }
});

// Array para almacenar respuestas (en prod, usar DB)
let responses = [];

// =====================================================
// RUTAS
// =====================================================

/**
 * GET / - Servir HTML principal
 */
app.get('/', (req, res) => {
    const htmlPath = path.join(__dirname, 'Encuesta_Post_Taller_Career_Bot.html');
    if (fs.existsSync(htmlPath)) {
        res.sendFile(htmlPath);
    } else {
        res.send(`
            <h1>✅ Servidor funcionando</h1>
            <p>Busca: Encuesta_Post_Taller_Career_Bot.html</p>
        `);
    }
});

/**
 * POST /api/feedback - Recibir respuestas de la encuesta
 */
app.post('/api/feedback', async (req, res) => {
    try {
        const { rating, takeaway, email, timestamp } = req.body;

        // Validar campos
        if (!rating || !takeaway || !email) {
            return res.status(400).json({ 
                error: 'Faltan campos requeridos (rating, takeaway, email)' 
            });
        }

        // Crear objeto de respuesta
        const newResponse = {
            timestamp: timestamp || new Date().toISOString(),
            rating: parseInt(rating),
            takeaway: takeaway.substring(0, 500), // Limitar longitud
            email: email.trim(),
            ratingLabel: getRatingLabel(parseInt(rating))
        };

        // Agregar al array
        responses.push(newResponse);
        console.log(`✅ Respuesta #${responses.length} recibida de ${email}`);

        // Enviar Excel por email
        await sendExcelByEmail(responses);

        res.json({ 
            success: true, 
            message: `Feedback recibido. Total de respuestas: ${responses.length}`,
            totalResponses: responses.length
        });

    } catch (error) {
        console.error('❌ Error en POST /api/feedback:', error);
        res.status(500).json({ 
            error: 'Error al procesar el feedback',
            details: error.message 
        });
    }
});

/**
 * GET /api/dashboard - Ver resumen de respuestas
 */
app.get('/api/dashboard', (req, res) => {
    try {
        const avgRating = responses.length > 0 
            ? (responses.reduce((sum, item) => sum + item.rating, 0) / responses.length).toFixed(1)
            : 'N/A';

        res.json({
            status: 'ok',
            totalResponses: responses.length,
            averageRating: avgRating,
            latestResponse: responses[responses.length - 1] || null,
            environment: NODE_ENV
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/**
 * GET /api/download-excel - Descargar Excel actual
 */
app.get('/api/download-excel', (req, res) => {
    try {
        if (responses.length === 0) {
            return res.status(400).json({ error: 'No hay respuestas aún' });
        }

        const workbook = XLSX.utils.book_new();
        
        const formattedData = responses.map((item, index) => ({
            '#': index + 1,
            'Fecha/Hora': new Date(item.timestamp).toLocaleString('es-PR'),
            'Puntuación': item.ratingLabel,
            '¿Qué te llevas?': item.takeaway,
            'Email': item.email
        }));

        const worksheet = XLSX.utils.json_to_sheet(formattedData);
        worksheet['!cols'] = [
            { wch: 5 },
            { wch: 20 },
            { wch: 15 },
            { wch: 40 },
            { wch: 25 }
        ];

        XLSX.utils.book_append_sheet(workbook, worksheet, 'Feedback');

        const fileName = `Feedback_Career_Bot_${new Date().toISOString().split('T')[0]}.xlsx`;
        const filePath = path.join(__dirname, 'temp', fileName);

        if (!fs.existsSync(path.join(__dirname, 'temp'))) {
            fs.mkdirSync(path.join(__dirname, 'temp'));
        }

        XLSX.writeFile(workbook, filePath);

        res.download(filePath, fileName, (err) => {
            if (err) console.error('Error en descarga:', err);
            setTimeout(() => {
                if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
            }, 1000);
        });

    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Error al generar Excel' });
    }
});

/**
 * GET /health - Health check (para Railway/Heroku)
 */
app.get('/health', (req, res) => {
    res.json({ 
        status: 'healthy',
        timestamp: new Date().toISOString(),
        environment: NODE_ENV,
        totalResponses: responses.length
    });
});

// =====================================================
// FUNCIONES AUXILIARES
// =====================================================

/**
 * Convertir número a emoji + texto
 */
function getRatingLabel(rating) {
    const labels = {
        1: '😞 Muy malo',
        2: '😐 Malo',
        3: '🙂 Bien',
        4: '😊 Muy bien',
        5: '🤩 ¡Excelente!'
    };
    return labels[rating] || 'Sin calificar';
}

/**
 * Generar y enviar Excel por email
 */
async function sendExcelByEmail(data) {
    if (!MAIL_USER || !MAIL_PASS) {
        console.warn('⚠️  Email deshabilitado (variables de entorno no configuradas)');
        return;
    }

    try {
        // Crear workbook
        const workbook = XLSX.utils.book_new();

        // Preparar datos
        const formattedData = data.map((item, index) => ({
            '#': index + 1,
            'Fecha/Hora': new Date(item.timestamp).toLocaleString('es-PR'),
            'Puntuación': item.ratingLabel,
            '¿Qué te llevas?': item.takeaway,
            'Email del Participante': item.email
        }));

        // Crear hoja
        const worksheet = XLSX.utils.json_to_sheet(formattedData);
        worksheet['!cols'] = [
            { wch: 5 },
            { wch: 20 },
            { wch: 15 },
            { wch: 40 },
            { wch: 25 }
        ];

        XLSX.utils.book_append_sheet(workbook, worksheet, 'Feedback Taller');

        // Guardar archivo
        const fileName = `Feedback_Career_Bot_${Date.now()}.xlsx`;
        const tempDir = path.join(__dirname, 'temp');
        const filePath = path.join(tempDir, fileName);

        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }

        XLSX.writeFile(workbook, filePath);

        // Preparar email
        const mailOptions = {
            from: MAIL_USER,
            to: RECIPIENT_EMAIL,
            subject: `📊 Nuevo Feedback del Taller Career Bot 24/7 (${data.length} respuestas)`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <div style="background: #E3263A; color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
                        <h2 style="margin: 0;">📊 FEEDBACK DEL TALLER</h2>
                        <p style="margin: 5px 0 0 0;">The 24/7 Career Bot: IA para Internships</p>
                    </div>

                    <div style="background: #f9f9f9; padding: 20px; border-radius: 0 0 8px 8px;">
                        <p><strong>¡Hola Malu!</strong></p>
                        
                        <p>Tienes <strong>${data.length} respuesta${data.length > 1 ? 's' : ''}</strong> nueva${data.length > 1 ? 's' : ''} del taller.</p>

                        <h3 style="color: #E3263A;">Resumen Rápido:</h3>
                        <ul>
                            <li><strong>Total de participantes:</strong> ${data.length}</li>
                            <li><strong>Puntuación promedio:</strong> ${(data.reduce((sum, item) => sum + item.rating, 0) / data.length).toFixed(1)} / 5</li>
                            <li><strong>Última respuesta:</strong> ${new Date(data[data.length - 1].timestamp).toLocaleString('es-PR')}</li>
                        </ul>

                        <p style="margin-top: 20px; padding: 15px; background: white; border-left: 4px solid #E3263A; border-radius: 4px;">
                            El archivo Excel con todas las respuestas está adjunto. 
                            <br/><strong>Archivo:</strong> ${fileName}
                        </p>

                        <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">

                        <p style="color: #666; font-size: 12px;">
                            © TIHA | Dra. Mariluz Serrano Ortiz | UPRRP
                        </p>
                    </div>
                </div>
            `,
            attachments: [
                {
                    filename: fileName,
                    path: filePath
                }
            ]
        };

        // Enviar
        await transporter.sendMail(mailOptions);
        console.log(`📧 Excel enviado a ${RECIPIENT_EMAIL}`);

        // Limpiar archivo después de 1 hora
        setTimeout(() => {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log(`🗑️  Archivo temporal eliminado`);
            }
        }, 3600000);

    } catch (error) {
        console.error('❌ Error al enviar email:', error.message);
    }
}

// =====================================================
// MANEJO DE ERRORES
// =====================================================

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
    console.error('❌ Uncaught Exception:', error);
});

// =====================================================
// INICIAR SERVIDOR
// =====================================================

const server = app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║   SERVIDOR CAREER BOT 24/7 ENCUESTA POST-TALLER EN LÍNEA  ║
╚════════════════════════════════════════════════════════════╝

🌍 Ambiente: ${NODE_ENV}
🎯 URL de la encuesta:
   http://localhost:${PORT}

📊 Dashboard:
   http://localhost:${PORT}/api/dashboard

💾 Descargar Excel:
   http://localhost:${PORT}/api/download-excel

⚙️  Variables de entorno:
   ${MAIL_USER ? '✅ MAIL_USER configurado' : '❌ MAIL_USER falta'}
   ${MAIL_PASS ? '✅ MAIL_PASS configurado' : '❌ MAIL_PASS falta'}
   RECIPIENT_EMAIL: ${RECIPIENT_EMAIL}

✅ Server listo para recibir feedback

    `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM recibido. Cerrando servidor...');
    server.close(() => {
        console.log('Servidor cerrado');
        process.exit(0);
    });
});

module.exports = app;
